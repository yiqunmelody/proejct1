/*Yiqun Zhang
*yzh282
*Lab 5 ArrayList
*lab on TR 18:15-19:30
*
*Yao Xiao
*yxiao24
*lab on MW 14:00-15:15
*/
package project1;

public interface Queue<AnyType> {
	public boolean isEmpty();
	public void enqueue(AnyType x);
	public AnyType dequeue();
	public AnyType peek();
}

