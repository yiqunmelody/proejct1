
package project1;

public class ShuntingYard {
	private enum Precedence
    {
        lparen(0), rparen(1), plus(2), minus(3), divide(4), times(5), lessThan(6),greaterThan(7),equalTo(8),logicalAND(9),logicalOR(10),logicalNOT(11),mod(12),sine(13),cosine(14),tangent(15), expo(16),eos(17), operand(18);
 
        private int index;
        Precedence(int index)
        {
            this.index = index;
        }
        public int getIndex()
        {
            return index;
        }        
    }
	private static final String[] operators= {"(", ")", "+", "-", "/", "*","<",">","=","&","|","!","%","sin","cos","tan", "^"," "};
	private static final int[] isp = {0, 19, 12, 12, 13, 13, 11, 11, 10, 9, 8, 16, 13, 14, 14, 14, 15, 0};
	private static final int[] icp = {20, 19, 12, 12, 13, 13, 11, 11, 10, 9, 8, 16, 13, 14, 14, 14, 15, 0};
	public static Precedence getToken(String symbol)
    {
        switch (symbol)
        {
        case "("  : return Precedence.lparen;
        case ")"  : return Precedence.rparen;
        case "+"  : return Precedence.plus;
        case "-"  : return Precedence.minus;
        case "/"  : return Precedence.divide;
        case "*"  : return Precedence.times;
        case "s"  : return Precedence.sine;
        case "c"  : return Precedence.cosine;
        case "t"  : return Precedence.tangent;
        case "%"  : return Precedence.mod;
        case "<"  : return Precedence.lessThan;
        case ">"  : return Precedence.greaterThan;
        case "="  : return Precedence.equalTo;
        case "&"  : return Precedence.logicalAND;
        case "|"  : return Precedence.logicalOR;
        case "!"  : return Precedence.logicalNOT;
        case "^"  : return Precedence.expo;
        case " "  : return Precedence.eos;
        default   : return Precedence.operand;
        }
    }
	public static URQueue<String> postfix(String infix) {
		URStack<Precedence> stack=new URStack<Precedence>();
		URQueue<String> postfix=new URQueue<String>();
		stack.push(Precedence.eos);
		Precedence token;
		int count=0;
		while(count<infix.length()) {
			//System.out.println("9");
			token=getToken(infix.substring(count,count+1));
			System.out.print(token.toString());
			if(token==Precedence.operand) {
				int i;
				for(i=count+1;i<infix.length();i++) {
					//System.out.println("1");
					token=getToken(infix.substring(i,i+1));
					if(token!=Precedence.operand) {
						break;
					}
				}
				postfix.enqueue(infix.substring(count,i-1));
				count=i-1;
			}
			else if(token==Precedence.rparen) {
				while(stack.peek().equals(Precedence.lparen)==false) {
					//System.out.println("7");
					postfix.enqueue(operators[stack.pop().getIndex()]);
				}
				stack.pop();
				count++;
			}
			else if(token==Precedence.sine||token==Precedence.cosine||token==Precedence.tangent) {
				postfix.enqueue(infix.substring(count,count+3));
				count+=3;
			}
			else if(token==Precedence.eos) {
				//System.out.println("8");
				continue;
			}
			else {
				while (isp[stack.peek().getIndex()] >= icp[token.getIndex()]) {
					//System.out.println("2");
                    postfix.enqueue(operators[stack.pop().getIndex()]);
				}
                stack.push(token);
                count++;
			}
			//System.out.println("6");
		}
			while (true) {
				token=stack.pop();
				if(token==null) {
					//System.out.println("3");
					break;
				}
				else if(token!=Precedence.eos) {
					//System.out.println("4");
	            postfix.enqueue(operators[token.getIndex()]);
				}
				else {
					//System.out.println("5");
					continue;
				}
			}
		return postfix;
	}
	   public static Double evaluatePostfix(URQueue<String> exp) 
	    { 
	        URStack<Double> stack=new URStack<Double>();
	        while(true) {
		        String s=exp.peek();
		        if(s.equals(null)) {
		        	break;
		        }
		        else if(s.equals("+")||s.equals("-")||s.equals("*")||s.equals("/")||s.equals("<")||s.equals(">")||s.equals("=")||s.equals("&")||s.equals("|")||s.equals("!")||s.equals("^")||s.equals("%")) 
		        {
		        	double value1=stack.pop();
		        	double value2=stack.pop();
		        	if(s.equals("+")) {
		        		stack.push(value1+value2);
		        	}
		        	if(s.equals("-")) {
		        		stack.push(value2-value1);
		        	}
		        	if(s.equals("*")) {
		        		stack.push(value2*value1);
		        	}
		        	if(s.equals("/")) {
		        		stack.push(value2/value1);
		        	}
		        	if(s.equals("<")) {
		        		if(value2<value1) {
		        			stack.push(1.0);
		        		}
		        		else {
		        			stack.push(0.0);
		        		}
		        	}
		        	if(s.equals(">")) {
		        		if(value2>value1) {
		        			stack.push(1.0);
		        		}
		        		else {
		        			stack.push(0.0);
		        		}
		        	}
		        	if(s.equals("=")) {
		        		if(value2==value1) {
		        			stack.push(1.0);
		        		}
		        		else {
		        			stack.push(0.0);
		        		}
		        	}
		        	if(s.equals("&")) {
		        		if(value1+value2==2.0) {
		        			stack.push(1.0);
		        		}
		        		else {
		        			stack.push(0.0);
		        		}
		        	}
		        	if(s.equals("|")) {
		        		if(value1+value2==0.0) {
		        			stack.push(0.0);
		        		}
		        		else {
		        			stack.push(1.0);
		        		}
		        	}
		        	if(s.equals("!")) {
		        		
		        	}
		        	if(s.equals("^")) {
		        		stack.push(Math.pow(value2, value1));
		        	}
		        	if(s.equals("%")) {
		        		stack.push(value2%value1);
		        	}	
		        }
		        else if(s.equals("sin")||s.equals("cos")||s.equals("tan")) {
		        	double value=stack.pop();
		        	if(s.equals("sin")) {
		        		stack.push(Math.sin(value));
		        	}
		        	if(s.equals("cos")) {
		        		stack.push(Math.cos(value));
		        	}
		        	if(s.equals("tan")) {
		        		stack.push(Math.tan(value));
		        	}
		        }
		        else {
		        	stack.push(Double.parseDouble(s));
		        }
	        }
		        return stack.pop();
	    } 
	public static void main (String[]arg) {
	System.out.print(evaluatePostfix(postfix("1")));
	}
}
