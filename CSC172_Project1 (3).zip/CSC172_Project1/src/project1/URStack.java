package project1;
/*
Yao Xiao
yxiao24
lab on MW 14:00-15:15

Yiqun Zhang
yzh282
lab on TR 18:15-19:30
 */
public class URStack<E> implements Stack<E>{
	URLinkedList<E> stack=new URLinkedList<E>();
	@Override
	public boolean isEmpty() {
		if(stack.isEmpty()) {
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void push(E x) {
		stack.addFirst(x);
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public E pop() {
		if(!isEmpty()) {
			E current=stack.get(0);
			stack.remove(0);
			return current;
		}
		
		// TODO Auto-generated method stub
		return null;
	}
	
	public E peek() {
		return stack.peekFirst();
	}
	public static void main(String[] args) {
		URStack<String> s=new URStack<String>();
		System.out.println(s.isEmpty());
		s.push("a");
		s.push("b");
		s.push("c");
		System.out.println(s.pop());
		System.out.println(s.pop());
		System.out.println(s.isEmpty());
		
	}
}
