/*Yiqun Zhang
*yzh282
*Lab 5 ArrayList
*lab on TR 18:15-19:30
*
*Yao Xiao
*yxiao24
*lab on MW 14:00-15:15
*/
package project1;

public class URQueue<E> implements Queue<E>{
	URLinkedList<E> queue=new URLinkedList<E>();
	@Override
	public boolean isEmpty() {
		return queue.isEmpty();
	}

	@Override
	public void enqueue(E x) {
		queue.addLast(x);
	}

	@Override
	public E dequeue() {
		return queue.pollFirst();
	}

	@Override
	public E peek() {
		return queue.peekFirst();
	}
	public void printQ() {
		for(E element:queue) {
			System.out.print(element+", ");
		}
		System.out.println();
	}
public static void main(String[]arg) {
	URQueue<String> a=new URQueue<String>();//create a new case of URStack
	System.out.println("AT FIRST, THE QUEUE isEmpty is "+a.isEmpty());//test isEmpty when the queue is empty
	a.enqueue("a");//Enqueue a string object
	a.enqueue("b");//Enqueue a string object
	a.enqueue("c");//Enqueue a string object
	System.out.println("AFTER ENQUEUE, THE QUEUE isEmpty is "+a.isEmpty());//test isEmpty when the queue isn't empty
	System.out.println("Dequeue an object: "+a.dequeue());//test dequeue
	System.out.println("Dequeue another object: "+a.dequeue());//test dequeue
	System.out.println("The peek is: "+a.peek());//return the first object in the queue
	
}
}
