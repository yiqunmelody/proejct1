package project1;
/*Yiqun Zhang
*yzh282
*Lab 5 LinkedList
*lab on TR 18:15-19:30
*
*Yao Xiao
*yxiao24
*lab on MW 14:00-15:15
*/
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class URLinkedList<E> implements URList<E>{
	URNode<E> firstNode;
	URNode<E> lastNode;
	int size=0;
	public URLinkedList() {
		
	}
	// Inserts the specified element at the beginning of this list.
	void addFirst(E e) {
		if(isEmpty()) {
			firstNode=lastNode=new URNode<E>(e,null,null);
		}
		else {
			firstNode=new URNode<E>(e,null,firstNode);
		}
		size++;
	}
	// Appends the specified element to the end of this list.
	void addLast(E e) {
		if(isEmpty()) {
			firstNode=lastNode=new URNode<E>(e,null,null);
		}
		else {
			URNode<E> addNode=new URNode<E>(e,lastNode,null);
			lastNode.setNext(addNode);
			lastNode=addNode;	
		}
		size++;
	}
	// Retrieves, but does not remove, the first element of this list, or returns null if this list is empty.
	E peekFirst() {
		if (size == 0)
			return null;
		return firstNode.element();
	
	}
		
	// Retrieves, but does not remove, the last element of this list, or returns null if this list is empty.
	E peekLast() {
		if (size == 0)
			return null;
		return lastNode.element();
	}
	// Retrieves and removes the first element of this list, or returns null if this list is empty.
	E pollFirst() {
		if (size == 0)
			 return null;	
		else {
			size--;
			E r = firstNode.element(); 
				if (firstNode.next() != null)
					firstNode.next().setPrev(null);
				else
				     lastNode = null;	  
				 firstNode = firstNode.next();
				 return r;
		}
		
	}
	// Retrieves and removes the last element of this list, or returns null if this list is empty.
	E pollLast() {
		if (size == 0)
			return null;
		else{
			size--;
			E r = lastNode.element();
			 if (lastNode.prev() != null)
				 lastNode.prev().setNext(null);
			 else
				 firstNode = null;
			 lastNode = lastNode.prev();
			 return r;
		}
	}
	@Override
	public boolean add(E e) {
		addLast(e);
		return true;
	}
	@Override
	public void add(int index, E element) {
		URNode<E> e = new URNode(element,null,null);
		if (index < size)
			{
				URNode<E> after = getNode(index);
				e.setNext(after);
				e.setPrev(after.prev());
				if (after.prev() == null)
					firstNode = e;
				else 		  
					after.prev().setNext(e);
			  	after.setPrev(e);
			    size++;
			 }
		else 
		{
			if (size == 0)
				firstNode = lastNode = e;
			else
			{
				e.setPrev(lastNode);
				lastNode.setNext(e);
				lastNode = e;
			}
			size++;
		}
	}
	@Override
	public boolean addAll(Collection<? extends E> c) {
		return addAll(size,c);
	}
	@Override
	public boolean addAll(int index, Collection<? extends E> c) {
		if (index < 0 || index > size)
			throw new IndexOutOfBoundsException("Index: " + index + ", Size:"+ size);
		int csize = c.size(); 
		if (csize == 0)
			return false;
		Iterator<? extends E> itr = c.iterator();
		URNode<E> after = null;
		URNode<E> before = null;
		if (index != size){
			 after = getNode(index);
			 before = after.prev();
		}
		else
			 before = lastNode;
		URNode<E> e = new URNode<E>(itr.next(),before,null);
		e.setPrev(before);
		URNode<E> prev = e;
		URNode<E> firstNew = e;
		for (int i= 1; i < csize; i++){
			 e = new URNode<E>(itr.next(),prev,e);
			 prev = e;
		 }
		 size += csize;
		 prev.setNext(after);
		 if (after != null)
			 after.setPrev(e);
		 else
			 lastNode = e;
		 if (before != null)
			 before.setNext(firstNew);
		 else
			 firstNode = firstNew;
		 return true;
	}
	@Override
	public void clear() {
		firstNode=null;
		lastNode=null;
		size=0;
	}
	@Override
	public boolean contains(Object o) {
		URNode<E> e = firstNode;
		while (e != null)
		 {
		 if (e.element().equals(o))
			 return true;
		 	e = e.next();
		 }
		 return false;
	}
	@Override
	public boolean containsAll(Collection<?> c) {
		Iterator<?> a=c.iterator();
		 while(a.hasNext()) {
			if(!contains(a.next())) {
				return false;
			}
		}
		return true;
	}
	
	public URNode<E> getNode(int n){
	 URNode<E> e;
	 if (n < size / 2){
		 e = firstNode;
		 while (n-- > 0)
			 e = e.next();
	 }
	 else{
		e = lastNode;
		while (++n < size)
			e = e.prev();
	 }
	return e;
	}
	@Override
	public E get(int index) {
		return getNode(index).element();
	}
	@Override
	public int indexOf(Object o) {
		int countOfIndex=0;
		URNode<E> current=firstNode;
		while(current!=null) {
			if(current.element().equals(o))
				return countOfIndex;
			current=current.next();
			countOfIndex++;
		}
		return -1;
	}
	@Override
	public boolean isEmpty() {
		return firstNode==null;
	}
	@Override
	public Iterator<E> iterator() {
		Object[] arr= new Object[size];
		for(int i=0;i<size;i++) {
			arr[i]=get(i);
		}
		return (Iterator<E>)Arrays.asList(arr);
	}
	@Override
	public E remove(int index) {
		if (index < 0 || index > size)
			 throw new IndexOutOfBoundsException("Index: " + index + ", Size:"+size);
		URNode<E> e = getNode(index);
	    size--;
	    if (size == 0)
	    	firstNode = lastNode = null;
	    else
	    {
	          if (e == firstNode)
	          	{
	        	  firstNode= e.next();
	        	  e.next().setPrev(null);
	          	}
	          else if (e == lastNode)
	          	{
			     lastNode = e.prev();
			     e.prev().setNext(null);
	          	}
	          else
	          	{
			      e.next().setPrev(e.prev());
			      e.prev().setNext(e.next());
	          	}
	    }
	    return e.element();
	}
	@Override
	public boolean remove(Object o) {
	    URNode<E> e = firstNode;
	    while (e != null)
	       {
	    	if (e.element().equals(o))
	        {	size--;
	        	if (size == 0)
	        	   firstNode = lastNode = null;
	        	else{
	        		if (e == firstNode)
	        	  {
	        	    firstNode = e.next();
	        	    e.next().setPrev(null);
	        	    }
	        	else if (e == lastNode)
	        	 	{
	        			lastNode = e.prev();
	        			e.prev().setNext(null);
	        	 	}
	        	else
	        	 {
	        		e.next().setPrev(e.prev());
	        		e.prev().setNext(e.next());
	        	 }
	        	 }
	          return true;
	         }
	      e = e.next();
	     }
	return false;
	}
	@Override
	public boolean removeAll(Collection<?> c) {
		if(!containsAll(c)) {
			return false;
		}
		Iterator<?> a=c.iterator();
		while(a.hasNext()) {
			remove(a.next());
		}
		return true;
		
	}
	@Override
	public E set(int index, E element) {
		if (index < 0 || index > size)
			throw new IndexOutOfBoundsException("Index: " + index + ", Size:" + size);
		 URNode<E> e = getNode(index);
		 E old = e.element();
		 e.setElement(element);
		 return old;
	}
	@Override
	public int size() {
		return size;
	}
	@Override
	public URList<E> subList(int fromIndex, int toIndex) {
		URLinkedList<E> sub=new URLinkedList<E>();
		URNode<E> subFirstNode=getNode(fromIndex);
		URNode<E> subLastNode=getNode(toIndex);
		subFirstNode.setPrev(null);
		subLastNode.setNext(null);
		for(int i=fromIndex+1;i<=toIndex-1;i++) {
			int count=0;
			sub.add(count,get(i));
		}
		sub.addFirst(subFirstNode.element());
		sub.addLast(subLastNode.element());
		return sub;
	}
	@Override
	public Object[] toArray() {
		Object[] array = new Object[size];
		 URNode<E> e = firstNode;
		 for (int i = 0; i < size; i++)
		 {
		    array[i] = e.element();
		    e = e.next();
		 }
		 return array;
	}
	public static void main(String[]arg) {
		URLinkedList<Integer> a=new URLinkedList<Integer>();
		a.add(1);
		a.add(10);
		a.add(15);
		a.add(19);
		System.out.println(a.subList(0, 2).size());
		for(int i=0;i<a.subList(0, 2).size();i++) {
			System.out.println(a.subList(0, 2).get(i));
		}
	}
}
